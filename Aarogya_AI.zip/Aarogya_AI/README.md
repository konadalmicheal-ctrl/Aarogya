# Aarogya AI — Intelligent Health Companion

A Flask-based educational healthcare web application for a diploma college project. It includes secure account basics, server-side sessions, CSRF protection, rate-limited API routes, OpenAI Responses API integration, temporary image analysis, an explicitly illustrative risk checker, health education pages, and a protected admin console.

## Important safety note
This app is for general education, not diagnosis or treatment. Never use AI output as a substitute for professional care. Do not upload identifying or unnecessary medical information. Image data is processed in memory by this app, then sent to the configured AI provider when image analysis is requested. Check provider privacy/retention terms before using real data.

## Quick start (Windows PowerShell)
1. Install Python 3.11+ and VS Code.
2. Open this folder in VS Code.
3. In the VS Code terminal, run:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   Copy-Item .env.example .env
   ```
4. Edit `.env`; set a long random `SECRET_KEY`. Add `OPENAI_API_KEY` only if you want real AI features.
5. Initialize database and create admin:
   ```powershell
   flask --app app init-db
   flask --app app create-admin
   ```
6. Run:
   ```powershell
   flask --app app run --debug
   ```
7. Open http://127.0.0.1:5000

See [START_HERE_TELUGU.md](START_HERE_TELUGU.md) for the beginner guide.

## Environment variables
See `.env.example`. Never commit `.env`. For production set `SESSION_COOKIE_SECURE=true`, a strong `SECRET_KEY`, a production `DATABASE_URL`, persistent database storage, HTTPS, a real email service, and a persistent rate-limit store.

## Tests
Run `pytest -q`. The tests use an isolated temporary SQLite database and do not make external AI calls.

## Deployment notes
A generic Gunicorn start command is `gunicorn "app:app"`. Choose a Python host that supports environment variables and persistent PostgreSQL. SQLite may not persist on ephemeral host filesystems. Set the production variables in the host dashboard, never in source control. Deployment is not performed by this source package.

## Known limitations
- Risk checking is illustrative only, not a validated clinical prediction.
- Profile editing, email verification, OAuth, and rich audit-event coverage are not implemented.
- Development password reset link is printed only when Flask debug/testing mode is active. Configure SMTP before production.
- In-memory rate limiting is suitable for local development only; configure Redis or another persistent backend for multi-worker deployment.
