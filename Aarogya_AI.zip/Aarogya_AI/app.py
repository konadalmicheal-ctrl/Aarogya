import click, logging, os
from flask import Flask, render_template, jsonify
from sqlalchemy import inspect
from config import Config
from extensions import db, csrf, limiter, mail
from models import User
from routes.main import bp as main_bp
from routes.auth import bp as auth_bp
from routes.admin import bp as admin_bp

def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)
    if app.config.get("SECRET_KEY") == "unsafe-development-key-change-me" and not app.testing:
        app.logger.warning("Using the development SECRET_KEY. Set a random SECRET_KEY in .env.")
    os.makedirs(app.instance_path, exist_ok=True)
    db.init_app(app); csrf.init_app(app); limiter.init_app(app); mail.init_app(app)
    app.register_blueprint(main_bp); app.register_blueprint(auth_bp); app.register_blueprint(admin_bp)

    @app.cli.command("init-db")
    def init_db():
        '''Create database tables for a fresh installation.'''
        with app.app_context():
            db.create_all()
        click.echo("Database tables initialized.")

    @app.cli.command("create-admin")
    @click.option("--email", prompt=True, help="Email address for the first admin")
    @click.option("--name", prompt=True, help="Admin display name")
    @click.password_option()
    def create_admin(email, name, password):
        '''Create or promote an admin account from a trusted local terminal.'''
        from utils.validation import clean_email, clean_name, valid_password
        email = clean_email(email)
        name = clean_name(name)
        if not email or not name or not valid_password(password):
            raise click.ClickException("Use a valid email/name and a password of at least 10 characters.")
        with app.app_context():
            user = User.query.filter_by(email=email).first()
            if not user:
                user = User(name=name, email=email)
                db.session.add(user)
            user.set_password(password)
            user.is_admin = True
            db.session.commit()
        click.echo("Admin account created/updated.")

    @app.errorhandler(413)
    def too_large(_error):
        return jsonify(error="Upload too large. Choose an image within the configured size limit."), 413

    @app.errorhandler(403)
    def forbidden(_error):
        return render_template("error.html", code=403, message="You do not have permission to view this page."), 403

    @app.errorhandler(404)
    def not_found(_error):
        return render_template("error.html", code=404, message="The page you requested was not found."), 404

    @app.errorhandler(500)
    def server_error(_error):
        db.session.rollback()
        app.logger.exception("Unhandled server error")
        return render_template("error.html", code=500, message="Something went wrong. Please try again."), 500

    return app

app = create_app()
