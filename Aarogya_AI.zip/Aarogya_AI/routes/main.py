from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for, flash, current_app
from extensions import db, limiter
from models import User
from services.ai_service import chat_reply, analyze_image, AIServiceError
from services.risk_service import score_risk
from PIL import Image, UnidentifiedImageError
import io, logging

bp = Blueprint("main", __name__)
log = logging.getLogger(__name__)
ALLOWED_MIMES = {"image/jpeg", "image/png", "image/webp"}

def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

@bp.get("/")
def index():
    return render_template("index.html")

@bp.get("/dashboard")
def dashboard():
    user = current_user()
    if not user:
        return redirect(url_for("auth.login"))
    return render_template("dashboard.html", user=user)

@bp.get("/profile")
def profile():
    user = current_user()
    if not user:
        return redirect(url_for("auth.login"))
    return render_template("profile.html", user=user)

@bp.post("/api/chat")
@limiter.limit("10 per minute")
def api_chat():
    if not current_user():
        return jsonify(error="Please log in to use the AI assistant."), 401
    payload = request.get_json(silent=True) or {}
    message = payload.get("message", "")
    history = payload.get("history", [])
    if not isinstance(message, str) or not message.strip() or len(message) > 6000:
        return jsonify(error="Enter a message of up to 6,000 characters."), 400
    try:
        return jsonify(reply=chat_reply(message.strip(), history))
    except AIServiceError as exc:
        return jsonify(error=exc.public_message, retryable=exc.status >= 500), exc.status
    except Exception:
        log.exception("Unexpected chat failure")
        return jsonify(error="Something went wrong. Please retry."), 500

@bp.post("/api/vision")
@limiter.limit("5 per minute")
def api_vision():
    if not current_user():
        return jsonify(error="Please log in to use Aarogya Vision."), 401
    upload = request.files.get("image")
    question = request.form.get("question", "Explain this image for education.")
    if not upload or not upload.filename:
        return jsonify(error="Choose an image first."), 400
    if upload.mimetype not in ALLOWED_MIMES:
        return jsonify(error="Use a JPEG, PNG, or WEBP image."), 400
    raw = upload.read(current_app.config["MAX_CONTENT_LENGTH"] + 1)
    if len(raw) > current_app.config["MAX_CONTENT_LENGTH"]:
        return jsonify(error="Image is too large. Choose a smaller image."), 413
    try:
        img = Image.open(io.BytesIO(raw))
        img.verify()
        img = Image.open(io.BytesIO(raw))
        if img.width * img.height > 20_000_000:
            return jsonify(error="Image dimensions are too large. Choose a smaller image."), 413
        mime = {"JPEG":"image/jpeg","PNG":"image/png","WEBP":"image/webp"}.get(img.format)
        if mime not in ALLOWED_MIMES:
            return jsonify(error="The file content is not a supported image."), 400
    except (UnidentifiedImageError, OSError, ValueError):
        return jsonify(error="This image could not be read. Try a clear JPEG, PNG, or WEBP file."), 400
    try:
        return jsonify(explanation=analyze_image(raw, mime, question))
    except AIServiceError as exc:
        return jsonify(error=exc.public_message, retryable=exc.status >= 500), exc.status
    except Exception:
        log.exception("Unexpected vision failure")
        return jsonify(error="Image analysis failed. Please retry."), 500

@bp.post("/api/risk")
@limiter.limit("20 per minute")
def api_risk():
    if not current_user():
        return jsonify(error="Please log in to use the risk checker."), 401
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(result=score_risk(payload.get("category"), payload.get("data") or {}))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400

@bp.get("/health")
def health():
    ai_configured = bool(current_app.config.get("OPENAI_API_KEY"))
    try:
        db.session.execute(db.text("SELECT 1"))
        database = "ok"
    except Exception:
        database = "error"
    return jsonify(status="ok" if database == "ok" else "degraded", database=database, ai_configured=ai_configured)

@bp.get("/library")
def library():
    return render_template("library.html")

@bp.get("/privacy")
def privacy():
    return render_template("privacy.html")
