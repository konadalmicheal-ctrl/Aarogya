from functools import wraps
from flask import Blueprint, render_template, session, redirect, url_for, flash, request, abort
from sqlalchemy import func
from extensions import db, limiter
from models import User, AuditLog

bp = Blueprint("admin", __name__, url_prefix="/admin")

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = db.session.get(User, session.get("user_id")) if session.get("user_id") else None
        if not user or not user.is_admin:
            abort(403)
        return fn(*args, **kwargs)
    return wrapper

@bp.get("/")
@admin_required
def dashboard():
    page = max(1, request.args.get("page", 1, type=int))
    query = (request.args.get("q") or "").strip()[:100]
    users_query = User.query
    if query:
        users_query = users_query.filter(db.or_(User.email.ilike(f"%{query}%"), User.name.ilike(f"%{query}%")))
    pagination = users_query.order_by(User.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template("admin.html", total=User.query.count(), admins=User.query.filter_by(is_admin=True).count(),
                           pagination=pagination, query=query, ai_configured=bool(__import__("flask").current_app.config.get("OPENAI_API_KEY")))

@bp.post("/users/<int:user_id>/delete")
@admin_required
@limiter.limit("20 per hour")
def delete_user(user_id):
    actor = db.session.get(User, session["user_id"])
    target = db.session.get(User, user_id)
    if not target:
        flash("User not found.", "error")
    elif target.id == actor.id or target.is_admin:
        flash("Admin accounts cannot be deleted here.", "error")
    else:
        db.session.add(AuditLog(actor_id=actor.id, action="delete_user", detail=f"user_id={target.id}"))
        db.session.delete(target); db.session.commit()
        flash("User account deleted.", "success")
    return redirect(url_for("admin.dashboard"))
