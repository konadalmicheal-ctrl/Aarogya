from datetime import datetime, timedelta, timezone
import hashlib, secrets, logging
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, current_app
from flask_mail import Message
from extensions import db, mail, limiter
from models import User, PasswordResetToken
from utils.validation import clean_email, clean_name, valid_password

bp = Blueprint("auth", __name__, url_prefix="/auth")
log = logging.getLogger(__name__)

@bp.route("/register", methods=["GET", "POST"])
@limiter.limit("8 per hour")
def register():
    if request.method == "POST":
        name, email = clean_name(request.form.get("name")), clean_email(request.form.get("email"))
        password, confirm = request.form.get("password", ""), request.form.get("confirm_password", "")
        if not name or not email or not valid_password(password) or password != confirm:
            flash("Check your name, email, and password. Passwords must be 10–128 characters and match.", "error")
        elif User.query.filter_by(email=email).first():
            flash("An account with these details could not be created. Try logging in or use another email.", "error")
        else:
            user = User(name=name, email=email)
            user.set_password(password)
            db.session.add(user); db.session.commit()
            session.clear(); session["user_id"] = user.id
            flash("Account created successfully.", "success")
            return redirect(url_for("main.dashboard"))
    return render_template("register.html")

@bp.route("/login", methods=["GET", "POST"])
@limiter.limit("10 per 15 minutes")
def login():
    if request.method == "POST":
        email = clean_email(request.form.get("email"))
        user = User.query.filter_by(email=email).first() if email else None
        if not user or not user.check_password(request.form.get("password", "")):
            flash("Email or password is incorrect.", "error")
        else:
            session.clear(); session["user_id"] = user.id
            user.last_login_at = datetime.now(timezone.utc); db.session.commit()
            return redirect(url_for("admin.dashboard") if user.is_admin else url_for("main.dashboard"))
    return render_template("login.html")

@bp.post("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("main.index"))

def send_reset_email(user, raw_token):
    link = current_app.config["APP_BASE_URL"].rstrip("/") + url_for("auth.reset_password", token=raw_token)
    if current_app.config.get("MAIL_SERVER") and current_app.config.get("MAIL_DEFAULT_SENDER"):
        mail.send(Message("Aarogya AI password reset", recipients=[user.email], body=f"Use this one-time link within {current_app.config['RESET_TOKEN_MINUTES']} minutes: {link}"))
    elif current_app.testing or current_app.debug:
        log.info("Development password-reset link for %s: %s", user.email, link)
        print(f"\n[DEV ONLY] Aarogya AI reset link for {user.email}: {link}\n")
    else:
        log.error("Email service is not configured; reset email not sent.")

@bp.route("/forgot-password", methods=["GET", "POST"])
@limiter.limit("5 per hour")
def forgot_password():
    if request.method == "POST":
        email = clean_email(request.form.get("email"))
        user = User.query.filter_by(email=email).first() if email else None
        if user:
            raw = secrets.token_urlsafe(32)
            digest = hashlib.sha256(raw.encode()).hexdigest()
            token = PasswordResetToken(user_id=user.id, token_hash=digest,
                expires_at=datetime.now(timezone.utc) + timedelta(minutes=current_app.config["RESET_TOKEN_MINUTES"]))
            db.session.add(token); db.session.commit()
            try:
                send_reset_email(user, raw)
            except Exception:
                db.session.rollback()
                log.exception("Password reset email delivery failed")
        flash("If the account exists, password-reset instructions will be sent if email delivery is configured.", "success")
        return redirect(url_for("auth.login"))
    return render_template("forgot_password.html")

@bp.route("/reset-password/<token>", methods=["GET", "POST"])
@limiter.limit("10 per hour")
def reset_password(token):
    digest = hashlib.sha256(token.encode()).hexdigest()
    record = PasswordResetToken.query.filter_by(token_hash=digest, used_at=None).first()
    now = datetime.now(timezone.utc)
    if not record:
        flash("This reset link is invalid or expired. Request a new one.", "error")
        return redirect(url_for("auth.forgot_password"))
    expiry = record.expires_at
    if expiry.tzinfo is None:
        expiry = expiry.replace(tzinfo=timezone.utc)
    if expiry <= now:
        flash("This reset link is invalid or expired. Request a new one.", "error")
        return redirect(url_for("auth.forgot_password"))
    if request.method == "POST":
        password, confirm = request.form.get("password", ""), request.form.get("confirm_password", "")
        if not valid_password(password) or password != confirm:
            flash("Passwords must be 10–128 characters and match.", "error")
        else:
            record.user.set_password(password); record.used_at = now
            db.session.commit()
            flash("Password updated. Please log in.", "success")
            return redirect(url_for("auth.login"))
    return render_template("reset_password.html", token=token)
