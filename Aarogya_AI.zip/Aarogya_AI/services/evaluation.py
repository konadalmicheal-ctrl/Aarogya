"""Placeholder boundary for future clinically validated model evaluation.

Before any clinical use, define a target population, approved dataset, preprocessing,
held-out evaluation, calibration, fairness analysis, external validation, and clinical
governance. This project intentionally does not claim clinical predictive performance.
"""

def evaluate_model(model, features, labels):
    raise NotImplementedError("No validated dataset/model is included in Aarogya AI.")
