def score_risk(category, data):
    """Illustrative education-only score. Not a clinical prediction model."""
    category = (category or "").lower()
    try:
        if category == "diabetes":
            age = float(data.get("age", ""))
            bmi = float(data.get("bmi", ""))
            activity = data.get("activity", "some")
            if not 1 <= age <= 120 or not 10 <= bmi <= 80 or activity not in {"low","some","regular"}:
                raise ValueError
            score = min(100, max(0, (20 if age >= 45 else 5) + (30 if bmi >= 30 else 15 if bmi >= 25 else 0) + (15 if activity == "low" else 5 if activity == "some" else 0)))
            inputs = {"age_years": age, "bmi": bmi, "activity": activity}
        elif category == "heart":
            age = float(data.get("age", ""))
            systolic = float(data.get("systolic", ""))
            smoking = data.get("smoking", "no")
            if not 1 <= age <= 120 or not 60 <= systolic <= 260 or smoking not in {"yes","no"}:
                raise ValueError
            score = min(100, (20 if age >= 45 else 5) + (35 if systolic >= 140 else 20 if systolic >= 120 else 0) + (20 if smoking == "yes" else 0))
            inputs = {"age_years": age, "systolic_bp_mmHg": systolic, "smoking": smoking}
        elif category in {"kidney", "liver"}:
            marker = float(data.get("marker", ""))
            if not 0 <= marker <= 10000:
                raise ValueError
            score = None
            inputs = {"user_entered_marker_value": marker, "unit": (data.get("unit") or "not specified")[:20]}
        else:
            raise ValueError
    except (ValueError, TypeError):
        raise ValueError("Please enter valid values within the shown ranges.")
    if score is None:
        message = "No score calculated: kidney and liver markers depend on the specific test, units, age, and clinical context. Discuss the report with a clinician."
        band = "Not scored"
    else:
        band = "Higher demo indicator" if score >= 55 else "Middle demo indicator" if score >= 25 else "Lower demo indicator"
        message = "This is a made-up illustrative score for demonstrating form logic, not a validated risk prediction and not a diagnosis."
    return {"category": category, "score": score, "band": band, "inputs": inputs, "method": "Simple illustrative rules only; no trained model or clinical validation.", "message": message}
