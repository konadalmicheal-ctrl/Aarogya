import base64
import logging
from openai import OpenAI, APIConnectionError, APIStatusError, RateLimitError, AuthenticationError
from flask import current_app

log = logging.getLogger(__name__)

class AIServiceError(Exception):
    def __init__(self, public_message, status=503):
        super().__init__(public_message)
        self.public_message = public_message
        self.status = status

def _client():
    key = current_app.config.get("OPENAI_API_KEY", "")
    if not key:
        raise AIServiceError("AI is not configured yet. Add OPENAI_API_KEY to your .env file and restart the server.")
    return OpenAI(api_key=key, timeout=45, max_retries=1)

def _call_error(exc):
    log.warning("AI provider request failed: %s", type(exc).__name__)
    if isinstance(exc, AuthenticationError):
        return AIServiceError("The AI API key was rejected. Check the key in .env.", 502)
    if isinstance(exc, RateLimitError):
        return AIServiceError("The AI service is rate-limited or billing/usage access is unavailable. Check your provider usage and billing.", 503)
    if isinstance(exc, APIConnectionError):
        return AIServiceError("Could not reach the AI service. Check your internet connection and retry.", 503)
    if isinstance(exc, APIStatusError):
        if exc.status_code in (403, 404):
            return AIServiceError("The configured AI model may be unavailable to this account. Check model access and configuration.", 502)
        return AIServiceError("The AI service returned an error. Please retry later.", 502)
    return AIServiceError("The AI request failed. Check server logs and configuration.", 502)

def chat_reply(message, history=None):
    client = _client()
    history = history or []
    safe_history = []
    for item in history[-8:]:
        if isinstance(item, dict) and item.get("role") in ("user", "assistant") and isinstance(item.get("content"), str):
            safe_history.append({"role": item["role"], "content": item["content"][:3000]})
    instructions = (
        "You are Aarogya AI, a warm health-education assistant. Support English and Telugu. "
        "Explain health concepts simply, including common lab terminology. You are not a doctor. "
        "Do not diagnose, prescribe, or tell users to stop medication. Encourage a qualified clinician "
        "for personal medical decisions. For possible emergency symptoms, advise contacting local emergency services. "
        "Avoid asking for identifying information. Be clear about uncertainty."
    )
    try:
        response = client.responses.create(
            model=current_app.config["OPENAI_MODEL"],
            instructions=instructions,
            input=safe_history + [{"role": "user", "content": message[:6000]}],
        )
        text = (getattr(response, "output_text", "") or "").strip()
        if not text:
            raise AIServiceError("The AI returned an empty response. Please retry.", 502)
        return text
    except AIServiceError:
        raise
    except Exception as exc:
        raise _call_error(exc) from exc

def analyze_image(image_bytes, mime_type, question):
    client = _client()
    encoded = base64.b64encode(image_bytes).decode("ascii")
    prompt = (
        "You are Aarogya Vision, an educational image explainer. Describe visible content and readable text. "
        "For health reports, explain visible terms and values cautiously, including units and uncertainty. "
        "Do not diagnose from an image, infer identity, or claim this replaces professional examination. "
        "Mention if text is unclear. Avoid repeating unnecessary personal identifiers. User question: " + question[:1500]
    )
    try:
        response = client.responses.create(
            model=current_app.config["OPENAI_VISION_MODEL"],
            input=[{"role":"user","content":[
                {"type":"input_text","text":prompt},
                {"type":"input_image","image_url":f"data:{mime_type};base64,{encoded}"},
            ]}],
        )
        result = (getattr(response, "output_text", "") or "").strip()
        if not result:
            raise AIServiceError("The AI returned no image explanation. Try a clearer image.", 502)
        return result
    except AIServiceError:
        raise
    except Exception as exc:
        raise _call_error(exc) from exc
