document.addEventListener("DOMContentLoaded", () => {
 const form=document.querySelector("#vision-form"); if(!form) return;
 const file=document.querySelector("#vision-file"), preview=document.querySelector("#vision-preview"), remove=document.querySelector("#vision-remove");
 const error=document.querySelector("#vision-error"), result=document.querySelector("#vision-result");
 let objectUrl=null;
 function clearPreview(){if(objectUrl) URL.revokeObjectURL(objectUrl);objectUrl=null;file.value="";preview.removeAttribute("src");preview.hidden=true;remove.hidden=true;}
 file.addEventListener("change",()=>{error.hidden=true;result.hidden=true;const f=file.files[0];if(!f)return;
  if(!["image/jpeg","image/png","image/webp"].includes(f.type)){clearPreview();error.textContent="Choose a JPEG, PNG, or WEBP image.";error.hidden=false;return;}
  if(f.size>5*1024*1024){clearPreview();error.textContent="Image is too large. Maximum is 5 MB by default.";error.hidden=false;return;}
  if(objectUrl)URL.revokeObjectURL(objectUrl);objectUrl=URL.createObjectURL(f);preview.src=objectUrl;preview.hidden=false;remove.hidden=false;
 });
 remove.addEventListener("click",clearPreview);
 form.addEventListener("submit",async(e)=>{e.preventDefault();error.hidden=true;result.hidden=true;
  if(!file.files[0]){error.textContent="Choose an image first.";error.hidden=false;return;}
  const button=form.querySelector('button[type="submit"]'), old=button.textContent;button.disabled=true;button.textContent="Analyzing…";
  try{const data=new FormData();data.append("image",file.files[0]);data.append("question",document.querySelector("#vision-question").value);
   const csrf=form.querySelector('[name="csrf_token"]').value;const r=await fetch("/api/vision",{method:"POST",headers:{"X-CSRFToken":csrf},body:data});const json=await r.json();if(!r.ok)throw new Error(json.error||"Image analysis failed.");
   result.textContent=json.explanation;result.hidden=false;
  }catch(err){error.textContent=err.message||"Could not connect. Please retry.";error.hidden=false;}
  finally{button.disabled=false;button.textContent=old;}
 });
});
