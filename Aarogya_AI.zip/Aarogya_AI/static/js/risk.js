document.addEventListener("DOMContentLoaded", () => {
 const form=document.querySelector("#risk-form"); if(!form)return;
 const category=document.querySelector("#risk-category"), fields=document.querySelector("#risk-fields"), result=document.querySelector("#risk-result");
 const definitions={
  diabetes:[["age","Age (years)","number",1,120],["bmi","BMI (kg/m²)","number",10,80]],
  heart:[["age","Age (years)","number",1,120],["systolic","Systolic blood pressure (mmHg)","number",60,260]],
  kidney:[["marker","Test value (enter the value shown)","number",0,10000],["unit","Unit (optional)","text",null,null]],
  liver:[["marker","Test value (enter the value shown)","number",0,10000],["unit","Unit (optional)","text",null,null]]
 };
 function renderFields(){fields.replaceChildren();for(const [name,label,type,min,max] of definitions[category.value]){
  const wrap=document.createElement("label");wrap.textContent=label;const input=document.createElement("input");input.name=name;input.type=type;input.required=name!=="unit";if(min!==null){input.min=min;input.max=max;input.step="any";}wrap.append(input);fields.append(wrap);
 }
 if(category.value==="diabetes"||category.value==="heart"){
  const wrap=document.createElement("label");wrap.textContent=category.value==="diabetes"?"Activity level":"Do you smoke?";
  const select=document.createElement("select");select.name=category.value==="diabetes"?"activity":"smoking";
  (category.value==="diabetes"?[["low","Low"],["some","Some"],["regular","Regular"]]:[["no","No"],["yes","Yes"]]).forEach(([v,t])=>{const o=document.createElement("option");o.value=v;o.textContent=t;select.append(o);});wrap.append(select);fields.append(wrap);
 }
 }
 category.addEventListener("change",renderFields);renderFields();
 form.addEventListener("submit",async(e)=>{e.preventDefault();result.hidden=true;const data={};new FormData(form).forEach((v,k)=>{if(k!=="csrf_token")data[k]=v;});
 const btn=form.querySelector('button[type="submit"]'),old=btn.textContent;btn.disabled=true;btn.textContent="Calculating…";
 try{const csrf=form.querySelector('[name="csrf_token"]').value;const r=await fetch("/api/risk",{method:"POST",headers:{"Content-Type":"application/json","X-CSRFToken":csrf},body:JSON.stringify({category:category.value,data})});const json=await r.json();if(!r.ok)throw new Error(json.error||"Could not calculate.");
 const rdata=json.result;result.replaceChildren();const h=document.createElement("strong");h.textContent=rdata.band+(rdata.score===null?"":` · ${rdata.score}/100`);const p=document.createElement("p");p.textContent=rdata.message;const small=document.createElement("small");small.textContent=rdata.method;result.append(h,p,small);result.hidden=false;
 }catch(err){result.textContent=err.message||"Please retry.";result.hidden=false;}finally{btn.disabled=false;btn.textContent=old;}
 });
});
