document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("#chat-form");
  if (!form) return;
  const input = document.querySelector("#chat-input"), messages = document.querySelector("#chat-messages");
  const errorBox = document.querySelector("#chat-error"), send = form.querySelector("button");
  const history = [];
  function addMessage(role, text, label) {
    const item = document.createElement("div"); item.className = `message ${role}`;
    const tag = document.createElement("span"); tag.className = "message-label"; tag.textContent = label;
    const p = document.createElement("p"); p.textContent = text;
    item.append(tag, p); messages.append(item); messages.scrollTop = messages.scrollHeight;
  }
  form.addEventListener("submit", async (event) => {
    event.preventDefault(); const message = input.value.trim(); if (!message) return;
    errorBox.hidden = true; addMessage("user", message, "YOU"); history.push({role:"user",content:message});
    input.value = ""; input.disabled = true; send.disabled = true; send.textContent = "…";
    const loading = document.createElement("div"); loading.className = "message assistant loading"; loading.textContent = "Aarogya AI is thinking…"; messages.append(loading);
    try {
      const csrf = form.querySelector('[name="csrf_token"]').value;
      const response = await fetch("/api/chat", {method:"POST", headers:{"Content-Type":"application/json","X-CSRFToken":csrf}, body:JSON.stringify({message,history:history.slice(-8,-1)})});
      const data = await response.json(); loading.remove();
      if (!response.ok) throw new Error(data.error || "The request failed.");
      addMessage("assistant", data.reply, "AAROGYA AI"); history.push({role:"assistant",content:data.reply});
    } catch (error) { loading.remove(); errorBox.textContent = `${error.message || "Connection problem."} You can retry your question.`; errorBox.hidden = false; }
    finally { input.disabled = false; send.disabled = false; send.textContent = "➤"; input.focus(); }
  });
});
