// Authentication forms use standard HTML validation and Flask-WTF CSRF protection.
