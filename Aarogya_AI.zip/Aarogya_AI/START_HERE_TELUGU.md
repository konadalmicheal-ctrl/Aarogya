# Aarogya AI — Start Here (Telugu in English letters)

Ee guide Windows + VS Code beginner kosam.

## 1. Mundu install cheyyalsinavi
- Python 3.11 leda newer version install cheyyi. Install appudu **Add Python to PATH** tick cheyyi.
- VS Code install cheyyi.
- ZIP ni extract chesi `Aarogya_AI` folder ekkada undo gurthupettuko.

## 2. VS Code lo folder open cheyyadam
1. VS Code open cheyyi.
2. `File > Open Folder` click cheyyi.
3. Extract chesina `Aarogya_AI` folder select cheyyi.
4. `Terminal > New Terminal` click cheyyi.
5. Terminal path chivarilo `Aarogya_AI` undho check cheyyi. Vere folder aithe:
   ```powershell
   cd "C:\path\to\Aarogya_AI"
   ```
   `C:\path\to\Aarogya_AI` ni nee actual folder path tho replace cheyyi.

## 3. Virtual environment create cheyyadam
Terminal lo ee commands okkokkati run cheyyi:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```
Prompt mundu `(.venv)` kanipisthe environment activate ayindi.

### Activate error vaste
PowerShell permission error vasthe current terminal kosam:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```
Leda Command Prompt terminal open chesi:
```bat
.venv\Scripts\activate.bat
```

## 4. `.env` file create cheyyadam
Project root lo `.env.example` file untundi. Terminal lo:
```powershell
Copy-Item .env.example .env
```
VS Code Explorer lo `.env` open cheyyi. `SECRET_KEY` ni long random secret tho replace cheyyi. Example generate cheyyadaniki:
```powershell
python -c "import secrets; print(secrets.token_hex(32))"
```
Aa output ni `SECRET_KEY=` tarvata paste cheyyi. `.env` lo `OPENAI_API_KEY=` daggara nee own API key paste cheyyachu. API key HTML/JS lo pettaku; GitHub ki upload cheyyaku. API key lekapoyina website open avutundi, kani AI requests friendly setup error chupistayi.

`OPENAI_MODEL` and `OPENAI_VISION_MODEL` lo nee account ki access unna model peru undali. Provider API usage/billing access separate ga undachu. Key ni change chesaka server stop chesi restart cheyyi.

## 5. Database initialize cheyyadam
`Aarogya_AI` project root lo, virtual environment active ga undaga:
```powershell
flask --app app init-db
```
`Database tables initialized.` ani vaste tables create ayyayi. Local SQLite database file automatic ga create avutundi.

## 6. Admin account create cheyyadam
```powershell
flask --app app create-admin
```
Email, name, password adugutundi. Strong password enter cheyyi. Admin ga login avvadaniki ide trusted local setup command. Email `ADMIN_EMAIL` tho match avvali ani code lo automatic privilege rule ledu; command run chese trusted person matrame admin create cheyyali.

## 7. Website run cheyyadam
```powershell
flask --app app run --debug
```
Browser lo `http://127.0.0.1:5000` open cheyyi. `127.0.0.1` nee own laptop ni matrame refer chestundi; public website URL kaadu. Server stop cheyyadaniki terminal lo `Ctrl + C`.

Server restart: `Ctrl+C`, tarvata same run command. `.env` changes taruvata restart compulsory.

## 8. Features ela test cheyyali
- Register page lo account create cheyyi.
- Login/logout test cheyyi.
- Dashboard lo AI chat try cheyyi. Valid API key and model access unte real response vastundi.
- Aarogya Vision lo non-sensitive sample image upload cheyyi. Image provider ki pampabadutundi; real personal reports use cheyyaku.
- Risk checker demo test cheyyi. Result clinical prediction kaadu.
- Forgot password try cheyyi. Debug mode lo reset link terminal lo `[DEV ONLY]` label tho print avutundi. Link use chesi password reset cheyyi.
- Admin dashboard: admin account tho login ayyi `/admin/` open cheyyi.
- Health check: `http://127.0.0.1:5000/health`

## 9. Common errors
- **ModuleNotFoundError**: project root lo unnava check cheyyi; `(.venv)` active cheyyi; `pip install -r requirements.txt` malli run cheyyi.
- **Port already in use**: `flask --app app run --debug --port 5001` run cheyyi; browser lo `http://127.0.0.1:5001` open cheyyi.
- **Invalid API key / HTTP 401**: `.env` lo key correct ga undho check cheyyi; extra quotes/spaces remove cheyyi; key revoke ayindha check cheyyi; server restart cheyyi.
- **HTTP 403 / model unavailable**: account ki aa model access undho provider dashboard lo check cheyyi. Model name `OPENAI_MODEL` lo supported value ga set cheyyi.
- **HTTP 429**: usage limit, rate limit, or billing/access issue avvachu. Provider usage/billing page check cheyyi; konchem sepu tarvata retry cheyyi.
- **HTTP 500**: VS Code terminal lo error traceback choodu. Secret values/API key screenshots share cheyyaku.
- **ERR_CONNECTION_REFUSED**: Flask server run avutunda check cheyyi; correct port open cheyyi; terminal lo server error undho choodu.
- **Database/table error**: project root lo `flask --app app init-db` run cheyyi.
- **CSRF error**: page refresh cheyyi; old tab kakunda latest page nunchi form submit cheyyi.
- **Image rejected**: JPEG/PNG/WEBP use cheyyi; default max 5 MB; clear image select cheyyi.

## 10. Tests run cheyyadam
```powershell
pytest -q
```
Tests local temporary database use chestayi; real AI API calls cheyyavu.

## 11. GitHub safe upload
1. GitHub lo new repository create cheyyi.
2. `.gitignore` lo `.env`, database, `.venv` ignore avutunnayi ani check cheyyi.
3. `git status` lo `.env` kanipinchakudadhu.
4. Commands:
   ```powershell
   git init
   git add .
   git status
   git commit -m "Build Aarogya AI educational health companion"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
   git push -u origin main
   ```
   URL ni nee own GitHub repository URL tho replace cheyyi. `.env` add ayithe commit cheyyaku; remove chesi `.gitignore` check cheyyi. Already secret push chesunte key ni revoke/rotate cheyyali.

## 12. Online deployment
- Python hosting provider lo web service create cheyyi.
- Repository connect cheyyi.
- Build/install command: `pip install -r requirements.txt`
- Start command: `gunicorn "app:app"`
- Hosting dashboard lo environment variables add cheyyi: `SECRET_KEY`, `DATABASE_URL`, `OPENAI_API_KEY`, model names, mail settings, `SESSION_COOKIE_SECURE=true`, `APP_BASE_URL=https://nee-domain`.
- Persistent PostgreSQL configure cheyyi. Host ephemeral disk use chesthe SQLite database lose avvachu.
- Production lo SMTP/email provider configure cheyyi; reset link terminal lo print avvadam meeda depend avvaku.
- HTTPS enable cheyyi. Multi-worker deployment kosam `RATELIMIT_STORAGE_URI` ni managed Redis URL ki set cheyyi.
- Deploy ayyaka mobile data/mobile browser nunchi public HTTPS URL test cheyyi.

## Important
Aarogya AI educational project matrame. Diagnosis/treatment kosam use cheyyaku. API calls cost generate cheyyachu. Real health data upload cheyyakunda sample images tho college demo cheyyadam best.
