from models import User
from extensions import db

def test_home_and_library(client):
    assert client.get("/").status_code == 200
    assert client.get("/library").status_code == 200
    assert client.get("/privacy").status_code == 200
    assert client.get("/health").status_code == 200

def test_register_login_logout_and_session(client, app):
    response = client.post("/auth/register", data={
        "name":"Test Student", "email":"student@example.com",
        "password":"long-safe-password-123", "confirm_password":"long-safe-password-123"
    }, follow_redirects=True)
    assert response.status_code == 200
    assert b"Hello, Test Student" in response.data
    with app.app_context():
        user = User.query.filter_by(email="student@example.com").first()
        assert user is not None and user.password_hash != "long-safe-password-123"
    assert client.post("/auth/logout", follow_redirects=True).status_code == 200
    response = client.post("/auth/login", data={"email":"student@example.com","password":"long-safe-password-123"}, follow_redirects=True)
    assert response.status_code == 200
    assert b"Hello, Test Student" in response.data

def test_dashboard_requires_login(client):
    response = client.get("/dashboard")
    assert response.status_code == 302
    assert "/auth/login" in response.headers["Location"]

def test_chat_requires_login(client):
    response = client.post("/api/chat", json={"message":"hello"})
    assert response.status_code == 401

def test_admin_requires_admin(client):
    response = client.get("/admin/")
    assert response.status_code == 403

def test_vision_requires_login(client):
    response = client.post("/api/vision")
    assert response.status_code == 401

def test_reset_request_is_generic(client):
    response = client.post("/auth/forgot-password", data={"email":"unknown@example.com"}, follow_redirects=True)
    assert response.status_code == 200
    assert b"If the account exists" in response.data
