import pytest
from app import create_app
from extensions import db

@pytest.fixture()
def app(tmp_path):
    database = tmp_path / "test.sqlite"
    app = create_app({"TESTING": True, "WTF_CSRF_ENABLED": False, "SECRET_KEY": "test-secret",
                      "SQLALCHEMY_DATABASE_URI": f"sqlite:///{database}", "RATELIMIT_ENABLED": False,
                      "OPENAI_API_KEY": "", "APP_BASE_URL": "http://localhost"})
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()

@pytest.fixture()
def client(app):
    return app.test_client()
