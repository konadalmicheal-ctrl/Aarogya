import re
from email_validator import validate_email, EmailNotValidError

def clean_email(value):
    try:
        return validate_email((value or "").strip(), check_deliverability=False).normalized.lower()
    except EmailNotValidError:
        return None

def valid_password(value):
    return isinstance(value, str) and len(value) >= 10 and len(value) <= 128

def clean_name(value):
    value = re.sub(r"\s+", " ", (value or "").strip())
    return value[:80] if 2 <= len(value) <= 80 else None
